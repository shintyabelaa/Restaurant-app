import 'regenerator-runtime'; /* for async await transpile */
import '../styles/main.css';

console.log('Hello Coders! :)');

const dataJSON = {};

fetch('DATA.json')
.then(response => response.json())
.then(data => {
  const restaurantsList = document.getElementById('restaurants-list');

  data.restaurants.forEach(restaurant => {
    const restaurantItem = document.createElement('div');
    restaurantItem.classList.add('restaurant-item');

    const restaurantName = document.createElement('h2');
    restaurantName.innerText = restaurant.name;
    restaurantItem.appendChild(restaurantName);

    const restaurantDescription = document.createElement('p');
    restaurantDescription.innerText = restaurant.description;
    restaurantItem.appendChild(restaurantDescription);

    restaurantsList.appendChild(restaurantItem);
  });
})
.catch(error => console.error(error));